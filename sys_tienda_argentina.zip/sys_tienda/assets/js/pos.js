/* Punto de Venta · Alevia Pay Style */
(function () {
  const $ = (s) => document.querySelector(s);
  const IGV = 0.21; // 21% IVA
  const CLI0 = { id: 1, nombre: 'Cliente Varios', documento: '', tipo_doc: '', saldo_deuda: 0, limite_credito: 0, puntos: 0, cumple: false, telefono: '' };
  const S = {
    cart: [],
    cli: { ...CLI0 },
    tipo: 'TICKET',
    metodo: 'EFECTIVO',
    cat: 0,
    busy: false,
    promos: [],
    fid: { cada: 1000, valor: 10, cumple: 10 },
    canje: 0,
    cot: 0,
    last: null,
    ivaActivo: false
  };
  const r2 = (x) => Math.round((x + Number.EPSILON) * 100) / 100;
  
  const mCli = new bootstrap.Modal($('#mdlCli'));
  const mHold = new bootstrap.Modal($('#mdlHold'));
  const mOk = new bootstrap.Modal($('#mdlOk'));
  const mCatalog = new bootstrap.Modal($('#mdlCatalog'));
  const mQuick = new bootstrap.Modal($('#mdlQuick'));
  const mMov = new bootstrap.Modal($('#mdlMovCaja'));
  
  let lastId = 0, prods = [];

  // ---------- Motor de Precios ----------
  function calcLinea(i) {
    let precio = +i.precio_venta;
    if (+i.cantidad_mayor > 0 && +i.precio_mayor > 0 && i.cant >= +i.cantidad_mayor) precio = +i.precio_mayor;
    const base = r2(i.cant * precio); let best = 0, name = null;
    for (const pr of S.promos) {
      const ok = pr.alcance === 'TODO' || (pr.alcance === 'PRODUCTO' && +pr.producto_id === +i.id) || (pr.alcance === 'CATEGORIA' && +pr.categoria_id === +i.categoria_id);
      if (!ok) continue; let d = 0;
      if (pr.tipo === 'PORCENTAJE') d = base * pr.valor / 100;
      else if (pr.tipo === 'MONTO') d = Math.min(base, pr.valor * i.cant);
      else if (pr.tipo === 'NXM' && pr.lleva > pr.paga && pr.lleva > 0) d = Math.floor(i.cant / pr.lleva) * (pr.lleva - pr.paga) * precio;
      d = r2(Math.min(d, base)); if (d > best) { best = d; name = pr.nombre; }
    }
    return { precio, base, desc: best, promo: name, sub: r2(base - best), mayor: precio !== +i.precio_venta && precio === +i.precio_mayor };
  }

  function calc() {
    let bruto = 0, dPromo = 0;
    S.cart.forEach((i) => { i.c = calcLinea(i); bruto += i.c.base; dPromo += i.c.desc; });
    let neto = r2(bruto - dPromo);

    // Descuento manual ($ o %)
    const dVal = +$('#descVal').value || 0;
    const dTipo = $('#descTipo').value;
    let manual = dTipo === '%' ? r2(neto * dVal / 100) : Math.min(dVal, neto);
    neto = r2(neto - manual);

    // Recargo manual ($ o %)
    const rVal = +$('#recargoVal').value || 0;
    const rTipo = $('#recargoTipo').value;
    let recargo = rTipo === '%' ? r2(neto * rVal / 100) : rVal;
    neto = r2(neto + recargo);

    // Cumpleaños
    const dCumple = S.cli.id !== 1 && S.cli.cumple ? r2(neto * S.fid.cumple / 100) : 0;
    neto = r2(neto - dCumple);

    // Puntos
    let canje = S.cli.id !== 1 ? Math.min(Math.max(0, Math.floor(S.canje)), S.cli.puntos || 0) : 0;
    let dPuntos = r2(canje * S.fid.valor);
    if (dPuntos > neto) { canje = Math.floor(neto / S.fid.valor); dPuntos = r2(canje * S.fid.valor); }
    neto = r2(neto - dPuntos);

    // IVA (21%) opcional
    let montoIva = 0;
    if (S.ivaActivo) {
      montoIva = r2(neto * IGV);
      neto = r2(neto + montoIva);
    }

    return { bruto, dPromo, manual, recargo, dCumple, dPuntos, canje, montoIva, total: Math.max(0, neto) };
  }

  const total = () => calc().total;

  // ---------- Caja ----------
  async function checkCaja() {
    const r = await api('caja.php?a=estado');
    $('#lock').style.display = r.caja ? 'none' : 'grid';
    if (!r.caja) setTimeout(() => $('#apertura').select(), 200);
  }
  $('#btnAbrir').onclick = async () => {
    try { await api('caja.php', { a: 'abrir', monto: $('#apertura').value }); toast('Caja abierta'); checkCaja(); $('#pSearch').focus(); } catch (e) { toast(e.message, 'danger'); }
  };

  // ---------- Catálogo ----------
  async function loadCats() {
    const r = await api('pos.php?a=categorias');
    $('#chips').innerHTML = `<button class="chip on" data-c="0"><i class="bi bi-grid"></i>Todos</button>` + r.rows.map((c) => `<button class="chip" data-c="${c.id}"><i class="bi ${esc(c.icono)}"></i>${esc(c.nombre)}</button>`).join('');
  }
  async function loadProds() {
    const r = await api(`pos.php?a=productos&q=${encodeURIComponent($('#pSearch').value.trim())}&cat=${S.cat}`);
    prods = r.rows; S.promos = r.promos || [];
    $('#grid').innerHTML = prods.length ? prods.map((p) => {
      const enCarrito = (S.cart.find((x) => x.id === p.id) || {}).cant || 0, disp = p.stock - enCarrito;
      return `<button class="pcard ${disp <= 0 ? 'out' : ''}" data-id="${p.id}">
        <div class="pi" style="background:${p.color}22;color:${p.color}">${p.imagen ? `<img src="${APP.base}/assets/uploads/productos/${esc(p.imagen)}" alt="">` : `<i class="bi ${esc(p.icono)}"></i>`}</div>
        <div class="pn">${esc(p.nombre)}</div><div class="pp">${money(p.precio_venta)}</div>${S.promos.some((q) => q.alcance === 'TODO' || (q.alcance === 'PRODUCTO' && +q.producto_id === +p.id) || (q.alcance === 'CATEGORIA' && +q.categoria_id === +p.categoria_id)) ? '<span class="promo-tag"><i class="bi bi-percent"></i>Promo</span>' : ''}${+p.cantidad_mayor > 0 && +p.precio_mayor > 0 ? `<div class="pm">Desde ${fmt(p.cantidad_mayor, 0)}: ${money(p.precio_mayor)}</div>` : ''}
        <div class="ps ${p.stock <= p.stock_minimo ? 'low' : ''}">${disp <= 0 ? 'Sin stock' : 'Stock: ' + fmt(disp, disp % 1 ? 2 : 0) + ' ' + esc(p.unidad)}</div></button>`;
    }).join('') : '<div class="empty" style="grid-column:1/-1"><i class="bi bi-search"></i>Sin productos para esta búsqueda</div>';
  }

  $('#chips').addEventListener('click', (e) => { const b = e.target.closest('.chip'); if (!b) return; document.querySelectorAll('.chip').forEach((x) => x.classList.remove('on')); b.classList.add('on'); S.cat = +b.dataset.c; loadProds(); });
  $('#grid').addEventListener('click', (e) => { const b = e.target.closest('.pcard'); if (!b) return; const p = prods.find((x) => x.id === +b.dataset.id); b.classList.add('pop'); setTimeout(() => b.classList.remove('pop'), 250); add(p); mCatalog.hide(); });
  $('#btnCatalogToggle').onclick = () => { mCatalog.show(); loadCats(); loadProds(); };

  // ---------- Búsqueda y Código de Barras ----------
  async function searchBarcodeOrName() {
    const v = $('#pSearch').value.trim();
    if (!v) return;
    const mode = $('#searchMode').value;
    const r = await api(`pos.php?a=productos&q=${encodeURIComponent(v)}&cat=0`);
    let exact = null;
    if (mode === 'codigo') {
      exact = r.rows.find((p) => p.codigo_barras === v || p.codigo.toLowerCase() === v.toLowerCase());
    } else {
      exact = r.rows.length === 1 ? r.rows[0] : r.rows.find((p) => p.nombre.toLowerCase() === v.toLowerCase());
    }
    if (exact) {
      add(exact);
      $('#pSearch').value = '';
    } else if (r.rows.length > 0) {
      prods = r.rows;
      mCatalog.show();
      loadCats();
      loadProds();
    } else {
      toast('Producto no encontrado', 'warning');
    }
  }

  $('#btnSearchGo').onclick = searchBarcodeOrName;
  $('#pSearch').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      searchBarcodeOrName();
    }
  });

  // ---------- Carrito ----------
  function add(p, n = 1) {
    let it = null;
    if (p.is_quick) {
      it = S.cart.find((x) => x.is_quick && x.nombre === p.nombre && +x.precio_venta === +p.precio_venta);
    } else {
      it = S.cart.find((x) => !x.is_quick && x.id === p.id);
    }
    const nuevo = (it ? it.cant : 0) + n;
    if (nuevo > p.stock) return toast(`Stock máximo disponible: ${fmt(p.stock, p.stock % 1 ? 2 : 0)}`, 'warning');
    if (it) it.cant = nuevo;
    else {
      const cartUid = p.is_quick ? ('qk_' + Date.now() + '_' + Math.floor(Math.random() * 1000)) : p.id;
      S.cart.push({
        _uid: cartUid,
        id: p.id,
        nombre: p.nombre,
        unidad: p.unidad || 'UND',
        precio_venta: +p.precio_venta,
        precio_mayor: +p.precio_mayor || 0,
        cantidad_mayor: +p.cantidad_mayor || 0,
        categoria_id: p.categoria_id,
        cant: n,
        stock: +p.stock,
        is_quick: !!p.is_quick
      });
    }
    render();
    const c = $('#cart'); c.scrollTop = c.scrollHeight;
  }

  function render() {
    const T = calc(), t = T.total;
    const totalItems = S.cart.reduce((a, b) => a + b.cant, 0);
    const totalDesc = T.dPromo + T.manual + T.dCumple + T.dPuntos;

    $('#statProds').textContent = S.cart.length;
    $('#statItems').textContent = totalItems % 1 ? fmt(totalItems, 2) : totalItems;
    $('#statDesc').textContent = money(totalDesc);

    if (!S.cart.length) {
      $('#cart').innerHTML = `
        <div class="alevia-empty-state">
          <div class="alevia-empty-circle">
            <i class="bi bi-cart3"></i>
          </div>
          <h5 class="fw-bold mb-1">Tu carrito está vacío</h5>
          <p class="text-muted small">Escaneá un código de barras o buscá un producto para comenzar</p>
        </div>`;
    } else {
      let rowsHtml = S.cart.map((i) => `
        <tr class="alevia-cart-row" data-id="${i._uid || i.id}">
          <td style="width:48%">
            <div class="fw-bold text-dark text-truncate" style="max-width:240px">${esc(i.nombre)}</div>
            <div class="small text-muted">${money(i.c.precio)} / ${esc(i.unidad)}${i.c.promo ? ' <span class="badge bg-success-subtle text-success border border-success-subtle">' + esc(i.c.promo) + '</span>' : ''}</div>
          </td>
          <td style="width:22%">
            <div class="alevia-cart-stepper">
              <button data-q="-">−</button>
              <input type="number" step="any" min="0" value="${i.cant}" data-in>
              <button data-q="+">+</button>
            </div>
          </td>
          <td class="text-end fw-bold" style="width:20%">
            ${i.c.desc ? '<s class="text-muted small fw-normal d-block">' + money(i.c.base) + '</s>' : ''}
            ${money(i.c.sub)}
          </td>
          <td class="text-end" style="width:10%">
            <button class="btn btn-sm btn-light text-danger p-1" data-rm title="Quitar"><i class="bi bi-trash3"></i></button>
          </td>
        </tr>`).join('');

      $('#cart').innerHTML = `
        <div class="table-responsive">
          <table class="alevia-cart-table">
            <thead>
              <tr><th>Producto</th><th>Cantidad</th><th class="text-end">Subtotal</th><th></th></tr>
            </thead>
            <tbody>${rowsHtml}</tbody>
          </table>
        </div>`;
    }

    const row = (l, v, c) => `<div class="d-flex justify-content-between ${c || 'text-success'}"><span>${l}</span><b class="num">− ${money(v)}</b></div>`;
    $('#extraRows').innerHTML = (T.dPromo ? row('<i class="bi bi-percent"></i> Promociones', T.dPromo) : '') + (T.dCumple ? row('<i class="bi bi-gift"></i> Cumpleaños', T.dCumple) : '') + (T.dPuntos ? row('<i class="bi bi-stars"></i> Puntos canjeados (' + T.canje + ')', T.dPuntos) : '');
    
    const pr = $('#ptsRow'), tiene = S.cli.id !== 1 && S.cli.puntos > 0;
    pr.style.setProperty('display', tiene ? 'flex' : 'none', 'important');
    $('#ptsDisp').textContent = S.cli.puntos || 0;

    $('#tSub').textContent = money(T.bruto);
    $('#lblIvaMonto').textContent = money(T.montoIva);
    $('#tTotal').textContent = money(t);
    vuelto();
    $('#btnCobrar').disabled = !S.cart.length || S.busy;
  }

  $('#cart').addEventListener('click', (e) => {
    const row = e.target.closest('.alevia-cart-row'); if (!row) return; const it = S.cart.find((x) => String(x._uid || x.id) === String(row.dataset.id));
    if (e.target.closest('[data-rm]')) S.cart = S.cart.filter((x) => x !== it);
    const q = e.target.closest('[data-q]');
    if (q) {
      const n = it.cant + (q.dataset.q === '+' ? 1 : -1);
      if (n <= 0) S.cart = S.cart.filter((x) => x !== it);
      else if (n > it.stock) return toast('Sin más stock disponible', 'warning');
      else it.cant = n;
    }
    render();
  });

  $('#cart').addEventListener('change', (e) => {
    if (!e.target.matches('[data-in]')) return;
    const it = S.cart.find((x) => String(x._uid || x.id) === String(e.target.closest('.alevia-cart-row').dataset.id));
    let n = parseFloat(e.target.value);
    if (!(n > 0)) S.cart = S.cart.filter((x) => x !== it);
    else if (n > it.stock) { toast(`Stock máximo: ${it.stock}`, 'warning'); it.cant = it.stock; }
    else it.cant = Math.round(n * 100) / 100;
    render();
  });

  // ---------- Mostrar más / Ocultar ----------
  $('#btnCliMore').onclick = () => {
    const box = $('#boxMore');
    const isHidden = box.style.display === 'none';
    box.style.display = isHidden ? 'block' : 'none';
    $('#btnCliMore').textContent = isHidden ? 'Ocultar' : 'Mostrar más';
  };

  $('#descVal').addEventListener('input', render);
  $('#descTipo').addEventListener('change', render);
  $('#recargoVal').addEventListener('input', render);
  $('#recargoTipo').addEventListener('change', render);

  $('#btnIvaToggle').onclick = () => {
    S.ivaActivo = !S.ivaActivo;
    $('#btnIvaToggle').textContent = S.ivaActivo ? 'Desactivar' : 'Activar';
    $('#btnIvaToggle').className = S.ivaActivo ? 'btn btn-sm btn-primary py-0 px-2 fw-semibold' : 'btn btn-sm btn-outline-secondary py-0 px-2 fw-semibold';
    render();
  };

  $('#canje').addEventListener('input', () => { S.canje = Math.max(0, parseInt($('#canje').value) || 0); render(); });
  $('#canjeMax').onclick = () => { S.canje = S.cli.puntos; render(); const T = calc(); S.canje = T.canje; $('#canje').value = T.canje; render(); };
  
  $('#btnClear').onclick = async () => {
    if (S.cart.length && await confirmBox('Se quitarán todos los productos de la venta actual.', '¿Vaciar carrito?', 'Vaciar', true)) reset();
  };
  $('#btnCancelSale').onclick = () => $('#btnClear').click();

  function reset() {
    S.cart = []; S.cot = 0; $('#descVal').value = 0; $('#recargoVal').value = 0; $('#recibido').value = '';
    S.ivaActivo = false; $('#btnIvaToggle').textContent = 'Activar'; $('#btnIvaToggle').className = 'btn btn-sm btn-outline-secondary py-0 px-2 fw-semibold';
    setCli({ ...CLI0 }); setMetodo('EFECTIVO');
    render(); $('#pSearch').focus();
  }

  // ---------- Pago y Billetes ----------
  function vuelto() {
    const v = (+$('#recibido').value || 0) - total();
    $('#vuelto').textContent = money(v > 0 ? v : 0);
    $('#vuelto').style.color = v < 0 && $('#recibido').value ? 'var(--rose)' : '';
  }
  $('#recibido').addEventListener('input', vuelto);

  $('#quickBills').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    document.querySelectorAll('#quickBills button').forEach((x) => x.classList.remove('active'));
    b.classList.add('active');
    const v = b.dataset.v;
    if (v === 'exacto') $('#recibido').value = total().toFixed(2);
    else $('#recibido').value = (+v).toFixed(2);
    vuelto();
  });

  function setMetodo(m) {
    S.metodo = m;
    $('#selectMetodo').value = m;
    $('#cashBox').style.display = m === 'EFECTIVO' ? '' : 'none';
    if (m === 'EFECTIVO') $('#recibido').focus();
  }
  $('#selectMetodo').addEventListener('change', (e) => setMetodo(e.target.value));

  // ---------- Cliente ----------
  function setCli(c) {
    S.cli = c;
    $('#cliNameInput').value = c.nombre;
    render();
  }
  $('#cliBox').onclick = () => { mCli.show(); $('#cliQ').value = ''; loadCli(); setTimeout(() => $('#cliQ').focus(), 300); };
  $('#btnSearchCli').onclick = (e) => { e.stopPropagation(); $('#cliBox').click(); };

  async function loadCli() {
    const r = await api(`pos.php?a=clientes&q=${encodeURIComponent($('#cliQ').value.trim())}`);
    $('#cliList').innerHTML = r.rows.map((c) => `
      <div class="cl-item p-2 border-bottom" data-id="${c.id}">
        <div><b>${esc(c.nombre)}</b> <small class="text-muted">· ${c.documento || 'Sin doc'}</small></div>
        <span class="badge bg-light text-dark border">Seleccionar</span>
      </div>`).join('');
  }
  $('#cliQ').addEventListener('input', debounce(loadCli, 200));
  $('#cliList').addEventListener('click', async (e) => {
    const row = e.target.closest('.cl-item'); if (!row) return;
    const r = await api(`pos.php?a=cliente&id=${row.dataset.id}`);
    setCli(r.cliente); mCli.hide();
  });

  $('#ncSave').onclick = async () => {
    const d = { tipo_doc: $('#ncTipo').value, documento: $('#ncDoc').value.trim(), nombre: $('#ncNombre').value.trim() };
    if (!d.nombre) return toast('Ingresa el nombre del cliente', 'warning');
    try {
      const r = await api('pos.php', { a: 'cliente_nuevo', ...d });
      setCli(r.cliente); mCli.hide(); toast('Cliente registrado');
    } catch (e) { toast(e.message, 'danger'); }
  };

  // ---------- Modal Venta Rápida (F6) ----------
  function calcQkVuelto() {
    const m = parseFloat($('#qkMonto').value) || 0;
    const cant = parseFloat($('#qkCant').value) || 1;
    const tot = m * cant;
    const rec = parseFloat($('#qkRecibido').value) || 0;
    const v = rec - tot;
    $('#qkVuelto').textContent = money(v > 0 ? v : 0);
  }

  function setQkMetodo(m) {
    $('#qkMetodo').value = m;
    document.querySelectorAll('#qkMetodoBox button').forEach(b => {
      b.classList.toggle('active', b.dataset.m === m);
    });
    $('#qkEfectivoRow').style.display = m === 'EFECTIVO' ? 'block' : 'none';
    calcQkVuelto();
  }

  $('#qkMetodoBox').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    setQkMetodo(b.dataset.m);
  });

  $('#btnQuickSale').onclick = () => {
    mQuick.show();
    $('#qkMonto').value = '';
    $('#qkCant').value = 1;
    $('#qkConcepto').value = '';
    $('#qkRecibido').value = '';
    $('#qkVuelto').textContent = '$ 0';
    setQkMetodo('EFECTIVO');
    document.querySelectorAll('.btn-quick-concept').forEach(b => b.classList.remove('active'));
    setTimeout(() => {
      $('#qkMonto').focus();
    }, 300);
  };

  $('#quickConcepts').addEventListener('click', (e) => {
    const b = e.target.closest('.btn-quick-concept');
    if (!b) return;
    document.querySelectorAll('.btn-quick-concept').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    $('#qkConcepto').value = b.textContent.trim();
    $('#qkMonto').focus();
    $('#qkMonto').select();
  });

  $('#qkMonto').addEventListener('input', calcQkVuelto);
  $('#qkCant').addEventListener('input', calcQkVuelto);
  $('#qkRecibido').addEventListener('input', calcQkVuelto);

  // Agregar al carrito para combinar con otros productos
  $('#btnQkAdd').onclick = () => {
    const m = parseFloat($('#qkMonto').value);
    const cant = parseFloat($('#qkCant').value) || 1;
    if (!(m > 0)) {
      toast('Ingresa un monto válido mayor a 0', 'warning');
      $('#qkMonto').focus();
      return;
    }
    const nom = $('#qkConcepto').value.trim() || 'Venta rápida';
    add({
      id: 6294,
      codigo: 'CONCEPTO-RAPIDO',
      nombre: nom,
      unidad: 'UND',
      precio_venta: m,
      precio_mayor: 0,
      cantidad_mayor: 0,
      categoria_id: 9,
      stock: 9999,
      is_quick: true
    }, cant);
    mQuick.hide();
    toast(`«${nom}» agregado al carrito`);
  };

  // Cobro directo e instantáneo en 1 solo clic
  async function quickCobrarDirecto() {
    const m = parseFloat($('#qkMonto').value);
    const cant = parseFloat($('#qkCant').value) || 1;
    if (!(m > 0)) {
      toast('Ingresa un monto válido mayor a 0', 'warning');
      $('#qkMonto').focus();
      return;
    }
    const nom = $('#qkConcepto').value.trim() || 'Venta rápida';
    const metodo = $('#qkMetodo').value || 'EFECTIVO';
    const totalVenta = Math.round((m * cant) * 100) / 100;
    let rec = parseFloat($('#qkRecibido').value);
    if (metodo === 'EFECTIVO') {
      if (!rec || rec < totalVenta) rec = totalVenta;
    } else {
      rec = totalVenta;
    }

    const btn = $('#btnQkDirecto');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Cobrando…';

    try {
      const snap = { items: [{ n: nom, q: cant, s: totalVenta }], cli: CLI0 };
      const r = await api('pos.php', {
        a: 'venta',
        items: [{ id: 6294, cant: cant, precio: m, nombre: nom, is_quick: true }],
        cliente_id: 1,
        tipo: 'TICKET',
        metodo: metodo,
        recibido: rec,
        descuento: 0,
        canje_puntos: 0
      });

      mQuick.hide();
      S.last = { ...snap, nro: r.nro, total: r.total, tel: r.telefono, pts: r.puntos };
      lastId = r.id;
      $('#okNro').textContent = r.nro;
      $('#okTotal').textContent = money(r.total);
      $('#okVuelto').textContent = r.vuelto !== null && r.vuelto > 0 ? 'Vuelto: ' + money(r.vuelto) : 'Pago: ' + metodo.toLowerCase();
      $('#okPts').innerHTML = '';
      mOk.show();
      setTimeout(() => $('#okNew').focus(), 300);

      if ($('#checkPrintAuto').checked && Imprimir.directa()) {
        Imprimir.ticket(lastId);
      }
      toast('¡Venta rápida registrada en el historial!');
    } catch (e) {
      toast(e.message, 'danger');
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-check2-circle me-1"></i> Cobrar Ahora (Enter)';
    }
  }

  $('#btnQkDirecto').onclick = quickCobrarDirecto;

  $('#mdlQuick').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      quickCobrarDirecto();
    }
  });

  // ---------- Modal Movimientos de Caja (Ingreso / Egreso Rápido) ----------
  function openMovCaja(tipo) {
    $('#movTipo').value = tipo;
    const isIngreso = tipo === 'INGRESO';
    $('#movTitle').textContent = isIngreso ? 'Registrar Ingreso Rápido' : 'Registrar Egreso Rápido';
    $('#btnMovSave').className = isIngreso ? 'btn btn-success px-4 py-2 fw-bold' : 'btn btn-danger px-4 py-2 fw-bold';
    $('#btnMovSave').style.background = isIngreso ? '#10b981' : '#ef4444';
    $('#movDesc').value = '';
    $('#movMonto').value = '';

    const catSelect = $('#movCat');
    if (isIngreso) {
      catSelect.innerHTML = `
        <option value="Ventas">Ventas</option>
        <option value="Cobro de cuenta corriente">Cobro de cuenta corriente</option>
        <option value="Aporte de socios">Aporte de socios</option>
        <option value="Otros">Otros</option>
      `;
    } else {
      catSelect.innerHTML = `
        <option value="Otros">Otros</option>
        <option value="Alquiler">Alquiler</option>
        <option value="Servicios">Servicios</option>
        <option value="Sueldos">Sueldos</option>
        <option value="Impuestos">Impuestos</option>
      `;
    }

    $('#movMetodo').value = 'Efectivo';
    mMov.show();
    setTimeout(() => $('#movDesc').focus(), 300);
  }
  $('#btnIngreso').onclick = () => openMovCaja('INGRESO');
  $('#btnEgreso').onclick = () => openMovCaja('EGRESO');

  $('#btnMovSave').onclick = async () => {
    const tipo = $('#movTipo').value;
    const desc = $('#movDesc').value.trim();
    const monto = parseFloat($('#movMonto').value);
    const cat = $('#movCat').value;
    const metodo = $('#movMetodo').value;

    if (!(monto > 0)) return toast('Ingresa un monto válido mayor a 0', 'warning');
    const concepto = `${cat} · ${metodo}${desc ? ': ' + desc : ''}`;

    try {
      await api('caja.php', { a: 'movimiento', tipo, concepto, monto });
      toast(`${tipo === 'INGRESO' ? 'Ingreso' : 'Egreso'} registrado con éxito`);
      mMov.hide();
    } catch (e) { toast(e.message, 'danger'); }
  };

  // ---------- Cobrar ----------
  async function cobrar() {
    if (!S.cart.length || S.busy) return;
    const t = total();
    if (S.metodo === 'EFECTIVO' && !(+$('#recibido').value >= t)) {
      $('#recibido').focus();
      return toast('Ingresa el monto recibido (≥ total)', 'warning');
    }
    S.busy = true;
    $('#btnCobrar').disabled = true;
    $('#btnCobrar').innerHTML = '<span class="spinner-border spinner-border-sm"></span> Procesando…';
    try {
      const T = calc(), snap = { items: S.cart.map((i) => ({ n: i.nombre, q: i.cant, s: i.c.sub })), cli: S.cli };
      const r = await api('pos.php', {
        a: 'venta',
        items: S.cart.map((i) => ({ id: i.id, cant: i.cant, precio: i.precio_venta, nombre: i.nombre, is_quick: !!i.is_quick })),
        cliente_id: S.cli.id,
        tipo: 'TICKET',
        metodo: S.metodo,
        recibido: +$('#recibido').value || 0,
        descuento: T.manual,
        canje_puntos: T.canje,
        cotizacion_id: S.cot
      });
      S.last = { ...snap, nro: r.nro, total: r.total, tel: r.telefono, pts: r.puntos };
      lastId = r.id;
      $('#okNro').textContent = r.nro;
      $('#okTotal').textContent = money(r.total);
      $('#okVuelto').textContent = r.vuelto !== null ? 'Vuelto: ' + money(r.vuelto) : 'Pago: ' + S.metodo.toLowerCase();
      $('#okPts').innerHTML = r.puntos ? `<i class="bi bi-stars text-warning"></i> Puntos ganados: <b>${r.puntos}</b>` : '';
      mOk.show();
      setTimeout(() => $('#okNew').focus(), 300);

      // Impresión de ticket si está marcado
      if ($('#checkPrintAuto').checked && Imprimir.directa()) {
        Imprimir.ticket(lastId);
      }
    } catch (e) {
      toast(e.message, 'danger');
    }
    S.busy = false;
    $('#btnCobrar').innerHTML = `
      <span class="d-flex align-items-center gap-2">
        <i class="bi bi-check2-circle fs-5"></i>
        <span>VENTA</span>
      </span>
      <span class="btn-badge-kbd">F4</span>
    `;
    render();
  }

  $('#btnCobrar').onclick = cobrar;
  $('#okNew').onclick = () => { mOk.hide(); reset(); };
  $('#okPrint').onclick = () => Imprimir.ticket(lastId);

  // ---------- Atajos de Teclado ----------
  document.addEventListener('keydown', (e) => {
    if (e.key === 'F2') { e.preventDefault(); $('#btnCatalogToggle').click(); }
    if (e.key === 'F3') { e.preventDefault(); $('#pSearch').focus(); $('#pSearch').select(); }
    if (e.key === 'F4') { e.preventDefault(); cobrar(); }
    if (e.key === 'F6') { e.preventDefault(); $('#btnQuickSale').click(); }
    if (e.key === 'Escape') {
      if (document.querySelector('.modal.show')) return;
      e.preventDefault();
      $('#btnCancelSale').click();
    }
  });

  // Inicio
  checkCaja();
  render();
})();
