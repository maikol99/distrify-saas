<?php
$extraCss[] = BASE_URL . '/assets/css/pos_alevia.css?v=' . ASSET_V;
$extraJs[] = BASE_URL . '/assets/js/pos.js?v=' . ASSET_V;
$igv = cfg('igv', '0');
?>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/pos_alevia.css?v=<?= ASSET_V ?>">
<script>
window.POS_IGV = <?= (float)$igv ?>;
window.POS_EMPRESA = <?= json_encode(cfg('empresa_nombre')) ?>;
window.POS_COT = <?= (int)($_GET['cot'] ?? 0) ?>;
document.body.classList.add('pos-page');
window.addEventListener('beforeunload', function(){ document.body.classList.remove('pos-page'); });
</script>

<div class="alevia-pos-container" id="pos">
  <!-- Barra Superior: Diseño Fachero Redondeado con Borde Naranja (Imagen 1) -->
  <div class="alevia-topbar">
    <div class="alevia-search-box">
      <i class="bi bi-upc-scan fs-5 text-muted ms-1"></i>
      <input type="text" id="pSearch" placeholder="Buscar producto por código de barras o nombre… (F3)" autocomplete="off" autofocus>
      <div class="search-sep"></div>
      <select id="searchMode">
        <option value="codigo">Buscar por código</option>
        <option value="nombre">Buscar por nombre</option>
      </select>
      <button class="alevia-btn-search" id="btnSearchGo" title="Buscar"><i class="bi bi-search"></i></button>
    </div>
    
    <div class="alevia-top-actions">
      <button class="btn-alevia-action btn-alevia-orange" id="btnQuickSale"><i class="bi bi-lightning-charge-fill"></i> Venta Rápida (F6)</button>
      <button class="btn-alevia-action btn-alevia-green" id="btnIngreso"><i class="bi bi-plus-circle"></i> Ingreso</button>
      <button class="btn-alevia-action btn-alevia-red" id="btnEgreso"><i class="bi bi-dash-circle"></i> Egreso</button>
    </div>
  </div>

  <!-- Contenedor Principal: Carrito Izquierda / Resumen Derecha -->
  <div class="alevia-pos-body">
    
    <!-- LADO IZQUIERDO: Carrito de productos -->
    <div class="alevia-cart-card">
      <div class="alevia-cart-head">
        <h5>Carrito de productos</h5>
        <div class="alevia-cart-actions">
          <button class="btn-icon-soft text-primary" id="btnCatalogToggle" title="Abrir catálogo / categorías (F2)"><i class="bi bi-grid-3x3-gap"></i></button>
          <button class="btn-icon-soft" id="btnHold" title="Ventas en espera"><i class="bi bi-pause-circle"></i> <span class="badge bg-primary text-white rounded-pill ms-1" id="holdCount" style="font-size:.65rem">0</span></button>
          <button class="btn-icon-soft danger" id="btnClear" title="Vaciar carrito (F4)"><i class="bi bi-trash3"></i></button>
        </div>
      </div>

      <!-- Área de productos en carrito -->
      <div class="alevia-cart-content" id="cart"></div>

      <!-- Pie del carrito: Resumen de métricas -->
      <div class="alevia-cart-footer">
        <div class="alevia-metric-box">
          <div class="alevia-metric-ic" style="background:#ffedd5;color:#f97316"><i class="bi bi-bag"></i></div>
          <div><small>Productos</small><b id="statProds">0</b></div>
        </div>
        <div class="alevia-metric-box">
          <div class="alevia-metric-ic" style="background:#e0f2fe;color:#0284c7"><i class="bi bi-grid"></i></div>
          <div><small>Ítems</small><b id="statItems">0</b></div>
        </div>
        <div class="alevia-metric-box">
          <div class="alevia-metric-ic" style="background:#dcfce7;color:#16a34a"><i class="bi bi-percent"></i></div>
          <div><small>Descuento</small><b id="statDesc"><?= e(moneda()) ?> 0,00</b></div>
        </div>
      </div>
    </div>

    <!-- LADO DERECHO: Resumen de Venta -->
    <div class="alevia-summary-card">
      <div class="alevia-summary-head">
        <h6>Resumen de Venta</h6>
        <button class="btn btn-sm btn-light text-primary p-1" style="border-radius:8px" title="Estadísticas de venta"><i class="bi bi-graph-up-arrow"></i></button>
      </div>

      <!-- Cliente: Diseño exacto (borde suave, lupa pastel naranja) -->
      <div class="alevia-client-input" id="cliBox">
        <i class="bi bi-person"></i>
        <input type="text" id="cliNameInput" value="Cliente Varios" placeholder="Buscar cliente" readonly>
        <button class="alevia-client-btn" id="btnSearchCli"><i class="bi bi-search"></i></button>
      </div>

      <!-- Botón Mostrar más / Ocultar (Pill Naranja suave) -->
      <div class="mb-1">
        <button type="button" class="btn-pill-orange" id="btnCliMore">Mostrar más</button>
      </div>

      <!-- Panel Desplegable de Descuento, Recargo, IVA -->
      <div id="boxMore" style="display:none;" class="mb-2 p-2 bg-light rounded-3 border">
        <!-- Descuento -->
        <div class="row g-2 align-items-center mb-2">
          <div class="col-4 small fw-semibold text-muted">Descuento:</div>
          <div class="col-5">
            <input type="number" min="0" step="any" id="descVal" class="form-control form-control-sm text-end" value="0">
          </div>
          <div class="col-3">
            <select id="descTipo" class="form-select form-select-sm">
              <option value="$">$</option>
              <option value="%">%</option>
            </select>
          </div>
        </div>

        <!-- Recargo -->
        <div class="row g-2 align-items-center mb-2">
          <div class="col-4 small fw-semibold text-muted">Recargo:</div>
          <div class="col-5">
            <input type="number" min="0" step="any" id="recargoVal" class="form-control form-control-sm text-end" value="0">
          </div>
          <div class="col-3">
            <select id="recargoTipo" class="form-select form-select-sm">
              <option value="$">$</option>
              <option value="%">%</option>
            </select>
          </div>
        </div>

        <!-- IVA (21%) -->
        <div class="row g-2 align-items-center">
          <div class="col-4 small fw-semibold text-muted">IVA (21%):</div>
          <div class="col-4">
            <button type="button" id="btnIvaToggle" class="btn btn-sm btn-outline-secondary py-0 px-2 fw-semibold" style="font-size:.78rem">Activar</button>
          </div>
          <div class="col-4 text-end small fw-bold" id="lblIvaMonto">$0.00</div>
        </div>
      </div>

      <!-- Subtotal permanente -->
      <div class="d-flex justify-content-between align-items-center small text-muted px-1 mb-1">
        <span class="fw-semibold">Subtotal:</span>
        <b class="fs-6 text-dark" id="tSub"><?= e(moneda()) ?> 0,00</b>
      </div>
      
      <div id="extraRows" class="small px-1"></div>
      
      <div id="ptsRow" class="d-flex justify-content-between align-items-center small mb-1 px-1" style="display:none!important">
        <span><i class="bi bi-stars text-warning"></i> Puntos <b id="ptsDisp">0</b></span>
        <span class="d-flex align-items-center gap-1">Canjear <input type="number" min="0" step="1" id="canje" class="form-control form-control-sm text-end" style="width:65px;height:24px" value="0"><button class="btn-soft" id="canjeMax" style="padding:0 .4rem;font-size:.68rem">Máx</button></span>
      </div>

      <!-- TOTAL A COBRAR (Card Oscura Alevia) -->
      <div class="alevia-total-card">
        <div>
          <div class="lbl">TOTAL A COBRAR</div>
          <div class="val" id="tTotal"><?= e(moneda()) ?> 0,00</div>
        </div>
        <div class="alevia-total-badge-ic">
          <i class="bi bi-cash-stack"></i>
        </div>
      </div>

      <!-- Método de Pago -->
      <span class="alevia-label">MÉTODO DE PAGO:</span>
      <select class="form-select alevia-pay-select mb-2" id="selectMetodo">
        <option value="EFECTIVO" selected>💵 Efectivo</option>
        <option value="MERCADOPAGO">📱 Mercado Pago (QR)</option>
        <option value="TRANSFERENCIA">🏦 Transferencia (Alias/CBU)</option>
        <option value="DEBITO">💳 Tarjeta Débito</option>
        <option value="TARJETA">💳 Tarjeta Crédito</option>
        <option value="CREDITO">📓 Fiado / Cta Cte</option>
      </select>

      <!-- Tarjeta: Imprimir ticket automáticamente -->
      <div class="alevia-ticket-card">
        <label class="alevia-ticket-check" for="checkPrintAuto">
          <input type="checkbox" id="checkPrintAuto" checked>
          <span class="custom-chk"></span>
          <span class="lbl-text">Imprimir ticket automáticamente</span>
        </label>
      </div>

      <!-- Tarjeta: MONTO RECIBIDO ($) -->
      <div id="cashBox" class="alevia-cash-card">
        <span class="alevia-card-label">MONTO RECIBIDO ($)</span>
        
        <div class="alevia-received-input">
          <span class="curr">$</span>
          <input type="number" step="any" min="0" id="recibido" placeholder="0">
        </div>

        <div class="alevia-quick-bills" id="quickBills">
          <button type="button" class="alevia-bill-btn active" data-v="exacto">Exacto</button>
          <button type="button" class="alevia-bill-btn" data-v="2000">$2.000</button>
          <button type="button" class="alevia-bill-btn" data-v="5000">$5.000</button>
          <button type="button" class="alevia-bill-btn" data-v="10000">$10.000</button>
          <button type="button" class="alevia-bill-btn" data-v="20000">$20.000</button>
        </div>

        <div class="d-flex justify-content-between align-items-center pt-2 px-1 border-top" style="border-color:#f1f5f9!important">
          <small class="text-muted fw-semibold">Vuelto:</small>
          <b class="fs-5 num text-dark" id="vuelto"><?= e(moneda()) ?> 0,00</b>
        </div>
      </div>

      <!-- Botonera Inferior: Sin espacios vacíos, pegada directamente debajo de la card de monto -->
      <div class="alevia-action-footer">
        <!-- Botón Múltiples Medios (Morado con letras blancas) -->
        <button type="button" class="btn-multi-pago" id="btnMultiPago">
          <i class="bi bi-credit-card-2-front fs-5"></i>
          <span>Múltiples medios de pago</span>
        </button>

        <!-- Fila de VENTA y CANCELAR -->
        <div class="alevia-dual-btns">
          <button type="button" class="btn-alevia-venta" id="btnCobrar">
            <span class="d-flex align-items-center gap-2">
              <i class="bi bi-check2-circle fs-5"></i>
              <span>VENTA</span>
            </span>
            <span class="btn-badge-kbd">F4</span>
          </button>
          <button type="button" class="btn-alevia-cancel" id="btnCancelSale">
            <span class="d-flex align-items-center gap-2">
              <i class="bi bi-x-circle fs-5"></i>
              <span>CANCELAR</span>
            </span>
            <span class="btn-badge-kbd">ESC</span>
          </button>
        </div>
      </div>

    </div>
  </div>

  <!-- Caja cerrada overlay -->
  <div class="pos-lock" id="lock" style="display:none">
    <div class="cardx text-center" style="max-width:380px;border-radius:20px;padding:2rem">
      <div class="kpi-ic ic-amber mx-auto mb-3" style="width:64px;height:64px;font-size:1.8rem"><i class="bi bi-safe2"></i></div>
      <h5 class="fw-bold">Abre tu caja para vender</h5>
      <p class="text-muted small">Ingresa el efectivo inicial con el que empiezas el turno.</p>
      <input type="number" step="100" min="0" class="form-control form-control-lg text-center mb-3 fw-bold" id="apertura" placeholder="Monto inicial (<?= e(moneda()) ?>)" value="5000">
      <button class="btn-pos w-100 justify-content-center" id="btnAbrir"><i class="bi bi-unlock"></i> Abrir caja</button>
    </div>
  </div>
</div>

<!-- Modal Catálogo de Productos / Cuadrícula -->
<div class="modal fade" id="mdlCatalog" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content border-0" style="border-radius:22px">
      <div class="modal-header border-0 pb-0 px-4 pt-4">
        <h5 class="modal-title fw-bold"><i class="bi bi-grid me-2 text-primary"></i>Catálogo de Productos</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body px-4">
        <div class="chips mb-3" id="chips"></div>
        <div class="prod-grid" id="grid" style="max-height:480px;overflow-y:auto"></div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Venta Rápida (F6) - Estilo Alevia Pay -->
<div class="modal fade" id="mdlQuick" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered" style="max-width: 440px">
    <div class="modal-content border-0 shadow-lg" style="border-radius:24px">
      <div class="modal-header border-0 pb-0 px-4 pt-4 d-flex align-items-start justify-content-between">
        <div class="d-flex align-items-center gap-3">
          <div style="width:48px;height:48px;border-radius:14px;background:#fff7ed;color:#f59e0b;display:grid;place-items:center;font-size:1.4rem;flex-shrink:0">
            <i class="bi bi-lightning-charge-fill"></i>
          </div>
          <div>
            <h5 class="fw-bold mb-0 text-dark">Venta Rápida</h5>
            <small class="text-muted">Para productos sin código de barras</small>
          </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body px-4 pt-3 pb-4">
        <!-- CONCEPTOS RÁPIDOS -->
        <label class="small fw-bold text-muted text-uppercase mb-2 d-block" style="letter-spacing:.05em">Conceptos Rápidos de Kiosco</label>
        <div class="d-flex flex-wrap gap-2 mb-3" id="quickConcepts">
          <button type="button" class="btn-quick-concept">Pan</button>
          <button type="button" class="btn-quick-concept">Caramelos</button>
          <button type="button" class="btn-quick-concept">Gomitas</button>
          <button type="button" class="btn-quick-concept">Cigarrillos</button>
          <button type="button" class="btn-quick-concept">Hielo</button>
          <button type="button" class="btn-quick-concept">Fotocopias</button>
          <button type="button" class="btn-quick-concept">Bolsa</button>
          <button type="button" class="btn-quick-concept">Sueltos</button>
          <button type="button" class="btn-quick-concept">Varios</button>
        </div>

        <!-- Producto / Concepto -->
        <div class="mb-3">
          <label class="form-label small fw-bold text-dark mb-1">Producto / Concepto</label>
          <input type="text" class="form-control form-control-lg fs-6" id="qkConcepto" placeholder="Ej: Pan, Caramelos sueltos, Cigarrillos..." style="border-radius:12px;border:1.5px solid #fdba74">
        </div>

        <!-- Precio / Monto y Cantidad -->
        <div class="row g-2 mb-3">
          <div class="col-8">
            <label class="form-label small fw-bold text-dark mb-1">Precio / Monto ($)</label>
            <div class="input-group">
              <span class="input-group-text bg-light border-end-0 fw-bold" style="border-radius:12px 0 0 12px">$</span>
              <input type="number" step="any" min="0" id="qkMonto" class="form-control form-control-lg fs-6 fw-bold border-start-0" placeholder="0.00" style="border-radius:0 12px 12px 0">
            </div>
          </div>
          <div class="col-4">
            <label class="form-label small fw-bold text-dark mb-1">Cantidad</label>
            <input type="number" step="any" min="1" id="qkCant" class="form-control form-control-lg fs-6 fw-bold text-center" value="1" style="border-radius:12px">
          </div>
        </div>

        <!-- Medio de Pago para Cobro Directo -->
        <div class="mb-3">
          <label class="form-label small fw-bold text-dark mb-1">Medio de Pago</label>
          <div class="d-flex gap-1" id="qkMetodoBox">
            <button type="button" class="btn btn-outline-secondary btn-sm flex-fill active py-2 fw-bold" data-m="EFECTIVO" style="border-radius:10px">💵 Efectivo</button>
            <button type="button" class="btn btn-outline-secondary btn-sm flex-fill py-2 fw-bold" data-m="MERCADOPAGO" style="border-radius:10px">📱 MP</button>
            <button type="button" class="btn btn-outline-secondary btn-sm flex-fill py-2 fw-bold" data-m="DEBITO" style="border-radius:10px">💳 Débito</button>
            <button type="button" class="btn btn-outline-secondary btn-sm flex-fill py-2 fw-bold" data-m="TRANSFERENCIA" style="border-radius:10px">🏦 Transf.</button>
          </div>
          <input type="hidden" id="qkMetodo" value="EFECTIVO">
        </div>

        <!-- Paga con / Vuelto (si es Efectivo) -->
        <div class="mb-4 p-2 bg-light rounded-3" id="qkEfectivoRow" style="border:1px dashed #cbd5e1">
          <div class="row g-2 align-items-center">
            <div class="col-7">
              <label class="form-label small text-muted mb-0">Paga con ($) <span class="fw-normal">(opcional)</span></label>
              <input type="number" step="any" min="0" id="qkRecibido" class="form-control form-control-sm fw-bold" placeholder="Monto exacto" style="border-radius:8px">
            </div>
            <div class="col-5 text-end">
              <span class="small text-muted d-block">Vuelto:</span>
              <span class="fw-bold fs-6 text-success" id="qkVuelto">$ 0</span>
            </div>
          </div>
        </div>

        <!-- Botones de Acción -->
        <div class="d-flex gap-2 justify-content-between pt-2 border-top">
          <button type="button" class="btn btn-light px-3 py-2 fw-semibold text-muted" data-bs-dismiss="modal" style="border-radius:12px">Cancelar (ESC)</button>
          <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-warning text-dark px-3 py-2 fw-bold" id="btnQkAdd" style="border-radius:12px;border-color:#f97316" title="Suma este ítem al carrito para seguir cobrando más cosas">
              <i class="bi bi-cart-plus me-1"></i> Al Carrito
            </button>
            <button type="button" class="btn text-white px-3 py-2 fw-bold" id="btnQkDirecto" style="background:linear-gradient(135deg, #10b981, #059669);border:0;border-radius:12px" title="Registra la venta normal al instante y genera el ticket">
              <i class="bi bi-check2-circle me-1"></i> Cobrar Ahora (Enter)
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Movimientos de Caja (Ingreso / Egreso Rápido) -->
<div class="modal fade" id="mdlMovCaja" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered" style="max-width: 420px">
    <div class="modal-content border-0 shadow-lg" style="border-radius:20px">
      <div class="modal-header border-0 pb-0 px-4 pt-4">
        <h5 class="modal-title fw-bold text-dark" id="movTitle">Registrar Ingreso Rápido</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body px-4 pt-3 pb-4">
        <input type="hidden" id="movTipo" value="INGRESO">
        
        <div class="mb-3">
          <input type="text" class="form-control form-control-lg fs-6" id="movDesc" placeholder="Descripción" style="border-radius:10px">
        </div>
        
        <div class="mb-3">
          <input type="number" step="any" min="0" class="form-control form-control-lg fs-6" id="movMonto" placeholder="0" style="border-radius:10px">
        </div>
        
        <div class="mb-3">
          <select class="form-select form-select-lg fs-6" id="movCat" style="border-radius:10px">
            <!-- Rellenado dinámicamente por JS según sea INGRESO o EGRESO -->
          </select>
        </div>
        
        <div class="mb-4">
          <select class="form-select form-select-lg fs-6" id="movMetodo" style="border-radius:10px">
            <option value="Efectivo">Efectivo</option>
            <option value="Transferencia">Transferencia</option>
            <option value="Tarjeta de crédito">Tarjeta de crédito</option>
            <option value="Tarjeta de débito">Tarjeta de débito</option>
          </select>
        </div>
        
        <div class="d-flex gap-2 justify-content-end">
          <button type="button" class="btn btn-light px-4 py-2 fw-semibold text-muted" data-bs-dismiss="modal" style="border-radius:10px">Cancelar</button>
          <button type="button" class="btn btn-success px-4 py-2 fw-bold" id="btnMovSave" style="background:#10b981;border:0;border-radius:10px">Guardar</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Clientes -->
<div class="modal fade" id="mdlCli" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0" style="border-radius:20px">
      <div class="modal-body p-4">
        <div class="d-flex justify-content-between mb-3"><h6 class="fw-bold m-0">Seleccionar cliente</h6><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <input type="text" class="form-control mb-2" id="cliQ" placeholder="Buscar por nombre o documento…" autocomplete="off">
        <div id="cliList" style="max-height:260px;overflow:auto"></div>
        <hr><div class="fw-semibold small mb-2">Nuevo cliente rápido</div>
        <div class="row g-2">
          <div class="col-4"><select class="form-select form-select-sm" id="ncTipo"><option>DNI</option><option>CUIT</option><option>CUIL</option></select></div>
          <div class="col-8"><input class="form-control form-control-sm" id="ncDoc" placeholder="N° documento"></div>
          <div class="col-12"><input class="form-control form-control-sm" id="ncNombre" placeholder="Nombre / Razón social"></div>
          <div class="col-12"><button class="btn-soft w-100 justify-content-center" id="ncSave"><i class="bi bi-person-plus"></i> Guardar y usar</button></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Ventas en espera -->
<div class="modal fade" id="mdlHold" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0" style="border-radius:20px">
      <div class="modal-body p-4">
        <div class="d-flex justify-content-between mb-3"><h6 class="fw-bold m-0">Ventas en espera</h6><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div id="holdList"></div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Éxito Venta -->
<div class="modal fade" id="mdlOk" tabindex="-1" data-bs-backdrop="static">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content border-0 text-center" style="border-radius:22px">
      <div class="modal-body p-4">
        <div class="ok-ring mx-auto mb-3"><i class="bi bi-check-lg"></i></div>
        <h5 class="fw-bold mb-0">¡Venta registrada!</h5>
        <div class="text-muted small mb-2" id="okNro"></div>
        <div class="fs-2 fw-800 text-success mb-1" id="okTotal"></div>
        <div class="small text-muted mb-2" id="okVuelto"></div>
        <div class="small mb-3" id="okPts"></div>
        <div class="d-grid gap-2">
          <button class="btn btn-primary fw-bold" id="okPrint"><i class="bi bi-printer"></i> Imprimir ticket</button>
          <button class="btn text-white fw-bold" style="background:#25d366" id="okWa"><i class="bi bi-whatsapp me-1"></i> WhatsApp</button>
          <button class="btn btn-light fw-bold" id="okNew">Nueva venta <kbd>Enter</kbd></button>
        </div>
      </div>
    </div>
  </div>
</div>
