<?php
/**
 * Instalador · crea la BD sys_tienda, tablas, usuario admin y datos de demostración.
 * Ejecutar una sola vez:  http://localhost/sys_tienda/install.php
 * (Por seguridad, elimina este archivo cuando termines.)
 */
require_once __DIR__ . '/config/config.php';
// En producción, una vez instalado el sistema queda bloqueado: nadie puede reinstalar ni borrar datos desde internet.
$lockFile = __DIR__ . '/config/installed.lock';
if (APP_ENV === 'produccion' && is_file($lockFile)) {
    http_response_code(403);
    die('<h3 style="font-family:sans-serif">Instalación bloqueada</h3><p style="font-family:sans-serif">El sistema ya está instalado. Para reinstalar (esto BORRA todos los datos) elimina el archivo <code>config/installed.lock</code> desde el servidor.</p>');
}
set_time_limit(120);
$log = [];
try {
    $pdo = new PDO(sprintf('mysql:host=%s;port=%d;charset=utf8mb4', DB_HOST, DB_PORT), DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);

    // 1) Esquema
    $sql = file_get_contents(__DIR__ . '/database/sys_tienda.sql');
    $pdo->exec($sql);
    $pdo->exec('USE ' . DB_NAME);
    $pdo->exec("SET time_zone = '-03:00'");
    $log[] = 'Base de datos y tablas creadas.';
    require_once __DIR__ . '/includes/crm.php';
    crm_migrar($pdo);
    $log[] = 'Módulo CRM instalado (etapas del pipeline, etiquetas y plantillas base).';

    // 2) Usuarios (sucursal 1 = Central, 2 = Norte)
    $ins = $pdo->prepare('INSERT INTO usuarios (rol_id,sucursal_id,nombres,apellidos,usuario,email,password,cambiar_clave) VALUES (?,?,?,?,?,?,?,1)');
    $ins->execute([1, 1, 'Victor', 'Administrador', 'admin', 'admin@tienda.com', password_hash('admin123', PASSWORD_DEFAULT)]);
    $ins->execute([2, 1, 'María', 'Quispe', 'cajero', 'caja@tienda.com', password_hash('cajero123', PASSWORD_DEFAULT)]);
    $ins->execute([2, 2, 'Luis', 'Rojas', 'luis', 'luis@tienda.com', password_hash('cajero123', PASSWORD_DEFAULT)]);
    $log[] = 'Usuarios de demostración: admin/admin123 · cajero/cajero123 (Central) · luis/cajero123 (Norte). Al ingresar, el sistema pedirá cambiar estas contraseñas.';

    // 3) Categorías y productos
    $cats = [
        ['Kiosco y Golosinas','bi-cookie','#ec4899'], ['Bebidas','bi-cup-straw','#06b6d4'], ['Almacén','bi-basket3','#f59e0b'],
        ['Galletitas y Snacks','bi-box-seam','#f97316'], ['Lácteos y Fiambrería','bi-droplet-half','#3b82f6'], ['Cigarrillos y Varios','bi-tag','#8b5cf6'],
        ['Bebidas con Alcohol','bi-cup-hot','#ef4444'], ['Limpieza','bi-stars','#10b981'],
    ];
    $ic = $pdo->prepare('INSERT INTO categorias (nombre,icono,color) VALUES (?,?,?)');
    foreach ($cats as $c) $ic->execute($c);
    foreach (['Arcor','Coca-Cola','Quilmes','Bagley','La Serenísima','Terrabusi','Maradent','Guaymallén','Lays','Beldent','Cunnington','Ser'] as $m)
        $pdo->prepare('INSERT INTO marcas (nombre) VALUES (?)')->execute([$m]);

    // [cat, nombre, unidad, compra, venta, stock, minimo] -> Con +50% de margen Alevia Pay
    $prods = [
        [1,'Alfajor Guaymallén Chocolate','UND',400.00,600.00,100,20],[1,'Alfajor Havanna Mixto','UND',1200.00,1800.00,40,10],
        [1,'Chicles Beldent Menta','UND',500.00,750.00,80,20],[1,'Caramelos Sugus 50g','PQT',600.00,900.00,60,15],
        [1,'Chocolate Block 38g','UND',800.00,1200.00,50,15],[1,'Turrón Arcor 25g','UND',300.00,450.00,120,30],
        [2,'Coca-Cola 500ml','BOT',1000.00,1500.00,90,20],[2,'Coca-Cola 1.5L','BOT',1800.00,2700.00,60,15],
        [2,'Agua Villavicencio 500ml','BOT',700.00,1050.00,80,20],[2,'Gaseosa Cunnington Cola 2.25L','BOT',1200.00,1800.00,50,15],
        [2,'Speed Unlimited 250ml','LAT',1100.00,1650.00,70,20],[2,'Gatorade Manzana 500ml','BOT',1200.00,1800.00,40,10],
        [3,'Yerba Playadito 500g','PQT',2000.00,3000.00,40,10],[3,'Azúcar Ledesma 1kg','KG',900.00,1350.00,50,15],
        [3,'Fideos Matarazzo Guisero 500g','PQT',1100.00,1650.00,45,10],[3,'Aceite Cocinero 900ml','BOT',1600.00,2400.00,35,10],
        [4,'Papas Lays Clásicas 85g','BLS',1400.00,2100.00,50,15],[4,'Galletitas Oreo 118g','PQT',1000.00,1500.00,60,15],
        [4,'Galletitas Chocolinas 170g','PQT',1200.00,1800.00,55,15],[4,'Bizcochitos Don Satur Grasa','PQT',700.00,1050.00,70,20],
        [5,'Leche La Serenísima Entera 1L','CJA',1100.00,1650.00,60,15],[5,'Yogur Yogurísimo Frutilla 1L','BOT',1500.00,2250.00,30,10],
        [6,'Cigarrillos Marlboro Box 20','PQT',3200.00,3800.00,50,10],[6,'Cigarrillos Philip Morris Box 20','PQT',2900.00,3500.00,50,10],
        [6,'Encendedor Bic Chico','UND',800.00,1200.00,40,10],
        [7,'Cerveza Quilmes Clásica 1L','BOT',2200.00,3300.00,60,18],[7,'Cerveza Corona 330ml','BOT',1800.00,2700.00,48,12],
        [7,'Fernet Branca 750ml','BOT',9000.00,13500.00,20,5],
        [8,'Lavandina Ayudín 1L','BOT',900.00,1350.00,30,10],[8,'Detergente Magistral 300ml','BOT',1600.00,2400.00,35,10],
    ];
    $ip = $pdo->prepare('INSERT INTO productos (categoria_id,marca_id,codigo,codigo_barras,nombre,unidad,precio_compra,precio_venta,precio_mayor,cantidad_mayor,stock,stock_minimo,fecha_vencimiento) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $iss = $pdo->prepare('INSERT INTO stock_sucursal (producto_id,sucursal_id,stock) VALUES (?,?,?)');
    $ikx = $pdo->prepare("INSERT INTO movimientos_inventario (sucursal_id,producto_id,tipo,cantidad,stock_resultante,motivo,usuario_id,fecha) VALUES (?,?,'ENTRADA',?,?,'Stock inicial',1,NOW()-INTERVAL 61 DAY)");
    foreach ($prods as $i => $p) {
        $venc = (rand(0, 9) < 2) ? date('Y-m-d', strtotime('+' . rand(5, 25) . ' days')) : date('Y-m-d', strtotime('+' . rand(120, 400) . ' days'));
        $s1 = $p[5]; $s2 = (int)round($p[5] * 0.6);
        // precio mayorista de ejemplo en bebidas y abarrotes
        $mayor = in_array($p[0], [1, 2]) ? round($p[4] * 0.92, 2) : null; $cmay = $mayor ? 6 : 0;
        $ip->execute([$p[0], rand(1, 12), 'P' . str_pad($i + 1, 4, '0', STR_PAD_LEFT), '775' . rand(1000000000, 9999999999), $p[1], $p[2], $p[3], $p[4], $mayor, $cmay, $s1 + $s2, $p[6], $venc]);
        $pid = (int)$pdo->lastInsertId();
        foreach ([[1, $s1], [2, $s2]] as [$sid, $st]) { $iss->execute([$pid, $sid, $st]); $ikx->execute([$sid, $pid, $st, $st]); }
    }
    $log[] = count($prods) . ' productos en ' . count($cats) . ' categorías, con stock en 2 sucursales.';

    // 4) Clientes y proveedores
    $cl = ['Cliente Varios','Juan Carlos Rossi','María Elena Gómez','Kiosco Central SRL','Lucas Benítez','Maxikiosco Los Amigos','Agustina Morales','Facundo Romero','Lautaro Díaz','Sofía Álvarez'];
    $icl = $pdo->prepare('INSERT INTO clientes (tipo_doc,documento,nombre,telefono,saldo_deuda,puntos,fecha_nacimiento) VALUES (?,?,?,?,?,?,?)');
    foreach ($cl as $i => $n) $icl->execute([$i == 3 || $i == 5 ? 'RUC' : 'DNI', $i ? (string)($i == 3 || $i == 5 ? rand(20000000000, 20999999999) : rand(10000000, 79999999)) : null, $n, $i ? '9' . rand(10000000, 99999999) : null,
        in_array($i, [2, 4, 8]) ? rand(20, 180) : 0, $i ? rand(0, 120) : 0, in_array($i, [1, 7]) ? date('Y-m-d', strtotime('-' . rand(25, 45) . ' years')) : null]);
    // un cliente cumple años hoy (demostración) y otro en pocos días
    $pdo->exec("UPDATE clientes SET fecha_nacimiento = DATE_SUB(CURDATE(), INTERVAL 30 YEAR) WHERE id=2");
    $pdo->exec("UPDATE clientes SET fecha_nacimiento = DATE_SUB(DATE_ADD(CURDATE(), INTERVAL 3 DAY), INTERVAL 28 YEAR) WHERE id=8");
    foreach ([['20100070970','Distribuidora Alicorp SAC'],['20100128056','Gloria S.A.'],['20100113610','Backus y Johnston'],['20501234567','Mayorista Santa Rosa']] as $pv)
        $pdo->prepare('INSERT INTO proveedores (ruc,razon_social,contacto,telefono) VALUES (?,?,?,?)')->execute([$pv[0], $pv[1], 'Ventas', '01' . rand(2000000, 7999999)]);

    // Promociones de ejemplo
    $pr = $pdo->prepare('INSERT INTO promociones (nombre,tipo,alcance,producto_id,categoria_id,valor,lleva,paga,fecha_inicio,fecha_fin) VALUES (?,?,?,?,?,?,?,?,?,?)');
    $pr->execute(['2x1 en Chizitos', 'NXM', 'PRODUCTO', 24, null, 0, 2, 1, date('Y-m-d', strtotime('-5 days')), date('Y-m-d', strtotime('+30 days'))]);
    $pr->execute(['10% en Lácteos', 'PORCENTAJE', 'CATEGORIA', null, 3, 10, 0, 0, date('Y-m-d', strtotime('-5 days')), date('Y-m-d', strtotime('+30 days'))]);

    // Compras de ejemplo (sucursal central)
    $pc = $pdo->prepare('INSERT INTO compras (sucursal_id,proveedor_id,usuario_id,comprobante,fecha,total) VALUES (1,?,?,?,?,?)');
    $pd = $pdo->prepare('INSERT INTO detalle_compras (compra_id,producto_id,cantidad,costo_unitario,subtotal) VALUES (?,?,?,?,?)');
    $allP = $pdo->query('SELECT id,precio_compra FROM productos')->fetchAll();
    foreach ([[1,'F001-' . rand(1000,9999),12],[2,'F002-' . rand(1000,9999),6],[3,'F003-' . rand(1000,9999),2]] as $cc) {
        $tot = 0; $lines = [];
        foreach (array_rand($allP, 4) as $ix) { $pp = $allP[$ix]; $q = rand(10, 40); $lines[] = [$pp['id'], $q, $pp['precio_compra']]; $tot += $q * $pp['precio_compra']; }
        $pc->execute([$cc[0], 1, $cc[1], date('Y-m-d', strtotime('-' . $cc[2] . ' days')), $tot]); $cid = $pdo->lastInsertId();
        foreach ($lines as $l) $pd->execute([$cid, $l[0], $l[1], $l[2], $l[1] * $l[2]]);
    }

    // 5) Cajas abiertas hoy (una por sucursal) + ventas últimos 60 días
    $pdo->exec("INSERT INTO cajas (sucursal_id,usuario_id,fecha_apertura,monto_apertura,estado) VALUES (1,2, CONCAT(CURDATE(),' 07:30:00'), 200, 'ABIERTA'), (2,3, CONCAT(CURDATE(),' 07:45:00'), 150, 'ABIERTA')");
    $cajaDe = [1 => (int)$pdo->query('SELECT id FROM cajas WHERE sucursal_id=1')->fetchColumn(), 2 => (int)$pdo->query('SELECT id FROM cajas WHERE sucursal_id=2')->fetchColumn()];
    $usuDe = [1 => 2, 2 => 3];

    $stockProds = $pdo->query('SELECT id,precio_compra,precio_venta FROM productos')->fetchAll();
    $metodos = ['EFECTIVO','EFECTIVO','MERCADOPAGO','MERCADOPAGO','TRANSFERENCIA','DEBITO','TARJETA','CREDITO'];
    $iv = $pdo->prepare('INSERT INTO ventas (sucursal_id,caja_id,usuario_id,cliente_id,tipo_comprobante,serie,numero,fecha,subtotal,igv,total,metodo_pago,monto_recibido,vuelto,estado) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $id = $pdo->prepare('INSERT INTO detalle_ventas (venta_id,producto_id,cantidad,precio_unitario,costo_unitario,subtotal) VALUES (?,?,?,?,?,?)');
    $corr = [1 => ['TICKET' => 0, 'BOLETA' => 0, 'FACTURA' => 0], 2 => ['TICKET' => 0, 'BOLETA' => 0, 'FACTURA' => 0]];
    $serieDe = [1 => ['TICKET' => 'T001', 'BOLETA' => 'B001', 'FACTURA' => 'A001'], 2 => ['TICKET' => 'T002', 'BOLETA' => 'B002', 'FACTURA' => 'A002']];
    $pdo->beginTransaction();
    for ($d = 59; $d >= 0; $d--) {
        $dia = strtotime("-$d days"); $dow = (int)date('N', $dia);
        foreach ([1, 2] as $suc) {
            $base = (($dow >= 5 ? 42 : 28) + ($d < 30 ? 8 : 0) + rand(-5, 8)) * ($suc == 1 ? 1 : 0.65);
            if ($d == 0) $base = (int)((date('G') * 3.1 + 6) * ($suc == 1 ? 1 : 0.65));
            for ($k = 0; $k < (int)$base; $k++) {
                $hora = ($d == 0) ? rand(7, max(7, (int)date('G'))) : rand(7, 21);
                $f = date('Y-m-d', $dia) . sprintf(' %02d:%02d:%02d', $hora, rand(0, 59), rand(0, 59));
                if ($d == 0 && strtotime($f) > time()) $f = date('Y-m-d H:i:s', time() - rand(60, 3600));
                $tipo = rand(0, 9) < 6 ? 'TICKET' : (rand(0, 9) < 8 ? 'BOLETA' : 'FACTURA');
                $n = ++$corr[$suc][$tipo]; $items = []; $tot = 0;
                for ($j = 0, $m = rand(1, 5); $j < $m; $j++) { $p = $stockProds[array_rand($stockProds)]; $q = rand(1, 3); $items[] = [$p['id'], $q, $p['precio_venta'], $p['precio_compra']]; $tot += $q * $p['precio_venta']; }
                $met = $metodos[array_rand($metodos)]; $recib = $met === 'EFECTIVO' ? ceil($tot / 10) * 10 : $tot;
                $anul = rand(0, 99) < 2 ? 'ANULADA' : 'COMPLETADA';
                $iv->execute([$suc, $d == 0 ? $cajaDe[$suc] : null, $usuDe[$suc], rand(0, 3) ? 1 : rand(2, 10), $tipo, $serieDe[$suc][$tipo], $n, $f,
                    round($tot, 2), 0.00, round($tot, 2), $met, $recib, $recib - $tot, $anul]);
                $vid = $pdo->lastInsertId();
                foreach ($items as $it) $id->execute([$vid, $it[0], $it[1], $it[2], $it[3], $it[1] * $it[2]]);
            }
        }
        if (rand(0, 4) == 0) {
            $g = [['Servicio de luz', 'Servicios'], ['Bolsas y empaques', 'Insumos'], ['Pasaje de reparto', 'Transporte'], ['Reposición de gas', 'Insumos']][rand(0, 3)];
            $pdo->prepare('INSERT INTO gastos (sucursal_id,concepto,categoria,monto,fecha) VALUES (?,?,?,?,?)')->execute([rand(1, 2), $g[0], $g[1], rand(15, 90), date('Y-m-d', $dia)]);
        }
    }
    foreach ($corr as $suc => $tipos) foreach ($tipos as $t => $c) $pdo->prepare('UPDATE series_comprobantes SET correlativo=? WHERE tipo=? AND sucursal_id=?')->execute([$c, $t, $suc]);
    $pdo->commit();
    $pdo->exec("INSERT INTO auditoria (usuario_id,usuario,sucursal_id,accion,detalle) VALUES (1,'admin',1,'INSTALACION','Sistema instalado con datos de demostración')");
    $log[] = 'Ventas de demostración generadas (60 días, 2 sucursales).';

    // 6) CRM de demostración: clientes en distintos estados de salud + etiquetas, notas, tareas y oportunidades
    $pdo->exec("UPDATE ventas SET cliente_id=1 WHERE cliente_id IN (9,10) AND fecha > NOW() - INTERVAL 38 DAY");   // se enfrían (en riesgo / dormidos)
    $pdo->exec("UPDATE ventas SET cliente_id=1 WHERE cliente_id=5 AND fecha > NOW() - INTERVAL 20 DAY");
    $pdo->exec("UPDATE ventas SET cliente_id=1 WHERE cliente_id=7");                                                // prospecto sin compras
    $ipr = $pdo->prepare('INSERT INTO clientes (tipo_doc,documento,nombre,telefono,origen,creado_en) VALUES (?,?,?,?,?,?)');
    $ipr->execute(['DNI', (string)rand(10000000, 79999999), 'Panadería La Espiga', '9' . rand(10000000, 99999999), 'Referido', date('Y-m-d H:i:s', strtotime('-3 days'))]);
    $ipr->execute(['RUC', '20' . rand(100000000, 999999999), 'Minimarket Los Andes SAC', '9' . rand(10000000, 99999999), 'Redes sociales', date('Y-m-d H:i:s', strtotime('-9 days'))]);
    $orig = ['Tienda', 'Referido', 'WhatsApp', 'Redes sociales', 'Volante / publicidad'];
    foreach ($pdo->query('SELECT id FROM clientes WHERE id BETWEEN 2 AND 10')->fetchAll(PDO::FETCH_COLUMN) as $cid) $pdo->prepare('UPDATE clientes SET origen=? WHERE id=?')->execute([$orig[$cid % 5], $cid]);
    $tg = $pdo->prepare('INSERT IGNORE INTO crm_cliente_etiqueta (cliente_id,etiqueta_id) VALUES (?,?)');
    foreach ([[2, 1], [2, 3], [3, 3], [4, 2], [4, 5], [6, 5], [6, 2], [8, 3], [9, 4]] as $t) $tg->execute($t);
    $nt = $pdo->prepare('INSERT INTO crm_notas (cliente_id,usuario_id,tipo,texto,creado_en) VALUES (?,?,?,?,?)');
    $nt->execute([4, 1, 'LLAMADA', 'Pide precio por mayor de arroz y aceite para su bodega. Quedamos en cotizar el viernes.', date('Y-m-d H:i:s', strtotime('-2 days'))]);
    $nt->execute([6, 1, 'VISITA', 'Visita al restaurante: consumen ~40 kg de arroz por semana. Interesados en entrega a domicilio.', date('Y-m-d H:i:s', strtotime('-5 days'))]);
    $nt->execute([2, 2, 'WHATSAPP', 'Se le envió la promo de lácteos. Respondió que pasa el sábado.', date('Y-m-d H:i:s', strtotime('-1 days'))]);
    $nt->execute([9, 1, 'NOTA', 'Cliente antiguo que dejó de venir. Mencionó que se mudó de zona.', date('Y-m-d H:i:s', strtotime('-12 days'))]);
    $tk = $pdo->prepare('INSERT INTO crm_tareas (cliente_id,asignado_id,creado_por,titulo,tipo,prioridad,vence) VALUES (?,?,?,?,?,?,?)');
    $tk->execute([4, 1, 1, 'Enviar cotización de arroz y aceite por mayor', 'EMAIL', 'ALTA', date('Y-m-d 17:00:00', strtotime('+1 day'))]);
    $tk->execute([9, 1, 1, 'Llamar para reactivar: ofrecer 10% en su primera compra de regreso', 'LLAMAR', 'MEDIA', date('Y-m-d 10:00:00', strtotime('-1 day'))]);
    $tk->execute([6, 2, 1, 'Coordinar entrega a domicilio del pedido semanal', 'VISITA', 'ALTA', date('Y-m-d 09:00:00')]);
    $tk->execute([8, 1, 1, 'Felicitar por su cumpleaños y regalar un obsequio', 'WHATSAPP', 'BAJA', date('Y-m-d 12:00:00', strtotime('+3 days'))]);
    $op = $pdo->prepare('INSERT INTO crm_oportunidades (cliente_id,titulo,valor,etapa_id,responsable_id,origen,cierre_estimado,estado,orden,cerrado_en,creado_en) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
    $op->execute([4, 'Abastecimiento mensual de abarrotes', 3200, 4, 1, 'Referido', date('Y-m-d', strtotime('+10 days')), 'ABIERTA', 1, null, date('Y-m-d H:i:s', strtotime('-8 days'))]);
    $op->execute([6, 'Pedido semanal para restaurante + delivery', 1800, 3, 1, 'Tienda', date('Y-m-d', strtotime('+7 days')), 'ABIERTA', 1, null, date('Y-m-d H:i:s', strtotime('-5 days'))]);
    $op->execute([11, 'Pan y lácteos para panadería', 950, 2, 1, 'Referido', date('Y-m-d', strtotime('+14 days')), 'ABIERTA', 1, null, date('Y-m-d H:i:s', strtotime('-3 days'))]);
    $op->execute([12, 'Proveedor mensual de bebidas', 2400, 1, 1, 'Redes sociales', date('Y-m-d', strtotime('+25 days')), 'ABIERTA', 1, null, date('Y-m-d H:i:s', strtotime('-1 days'))]);
    $op->execute([3, 'Pedido de fiesta (licores y snacks)', 620, 5, 1, 'WhatsApp', null, 'GANADA', 1, date('Y-m-d H:i:s', strtotime('-4 days')), date('Y-m-d H:i:s', strtotime('-9 days'))]);
    $log[] = 'CRM de demostración: etiquetas, notas, tareas, oportunidades y clientes en distintos segmentos.';
    @file_put_contents($lockFile, 'Instalado: ' . date('Y-m-d H:i:s') . "\n");
    $ok = true;
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    $ok = false; $log[] = 'ERROR: ' . $e->getMessage();
}
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Instalación · SysTienda</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="assets/vendor/bootstrap/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light"><div class="container py-5" style="max-width:640px">
<div class="card shadow-sm border-0"><div class="card-body p-4">
<h4 class="mb-3"><?= $ok ? '✅ Instalación completada' : '❌ Error en la instalación' ?></h4>
<ul class="list-group mb-4"><?php foreach ($log as $l): ?><li class="list-group-item"><?= htmlspecialchars($l) ?></li><?php endforeach; ?></ul>
<?php if ($ok): ?><a class="btn btn-primary" href="login.php">Ir al login</a>
<span class="text-muted small ms-2">Elimina <code>install.php</code> en producción.</span><?php endif; ?>
</div></div></div></body></html>
